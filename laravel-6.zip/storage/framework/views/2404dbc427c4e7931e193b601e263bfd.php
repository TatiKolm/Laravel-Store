

<?php $__env->startSection('title', __("Products")); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center my-5">
        <h2><?php echo e(__("Products")); ?></h2>
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary"><?php echo e(__("Add")); ?></a>
    </div>

    <div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th><?php echo e(__("Image")); ?></th>
                    <th><?php echo e(__("Products")); ?></th>
                    <th><?php echo e(__("Trademarks")); ?></th>
                    <th><?php echo e(__("Actions")); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img src="<?php echo e($product->getImage()); ?>" alt="" style="height:100px">
                        </td>
                        <td>
                            <a href="<?php echo e(route('products.show', $product->slug)); ?>">
                                <?php echo e($product->title); ?></a>
                        </td>
                        <td>
                            <?php $__currentLoopData = $product->trademarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trademark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $trademark->name . '<br>'; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td class="d-flex">
                            <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-sm btn-warning">
                            <?php echo e(__("Edit")); ?>

                            </a>
                            <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" class="mx-3">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"
                                onclick="event.preventDefault(); if(confirm('Запись будет удалена. Продолжить?')){this.closest('form').submit();}">
                                <?php echo e(__("Delete")); ?>

                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/products/index.blade.php ENDPATH**/ ?>