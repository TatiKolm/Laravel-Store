<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary" >
        <div class="container">
          <a class="navbar-brand" href="<?php echo e(route('app.main')); ?>"><?php echo e(config("app.name")); ?></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="#"><?php echo e(__("app.menu.home")); ?></a>
              </li>
             

              <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <?php echo e(__('Trademarks')); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = $trademarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trademark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <?php echo e($trademark->name); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                
                </ul>
              </li>

            </ul>
            <ul class="navbar-nav d-flex align-items-center justify-content-end" style="margin-right:0">
            <?php if(! \Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'user')): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <?php echo e(__("app.menu.dashboard")); ?>

                </a>
                <ul class="dropdown-menu">
                  <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin|moderator')): ?>
                  <li>
                    <a class="dropdown-item" href="<?php echo e(route('categories.list')); ?>">
                    <?php echo e(__("app.menu.categories")); ?>

                    </a>
                  </li>
                  <?php endif; ?>
                  <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin|moderator')): ?>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('articles.index')); ?>">
                    <?php echo e(__("app.menu.news")); ?>

                    </a>
                </li>
                <?php endif; ?>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin|moderator')): ?>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('products.index')); ?>">
                    <?php echo e(__("Products")); ?>

                    </a>
                  </li>
                  <?php endif; ?>
                  <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin|moderator')): ?>
                  <li>
                    <a class="dropdown-item" href="<?php echo e(route('trademarks.index')); ?>">
                    <?php echo e(__("Trademarks")); ?>

                    </a>
                  </li>
                  <?php endif; ?>
                  <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'super-admin|admin')): ?>
                  <li>
                    <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">
                    <?php echo e(__("Users")); ?>

                    </a>
                  </li>
                  <?php endif; ?>
                  <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'super-admin')): ?>
                  <li>
                    <a class="dropdown-item" href="<?php echo e(route('roles.index')); ?>">
                    <?php echo e(__("Roles")); ?>

                    </a>
                  </li>
                  <?php endif; ?>
                  <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'super-admin')): ?>
                  <li>
                    <a class="dropdown-item" href="<?php echo e(route('permissions.index')); ?>">
                    <?php echo e(__("Permissions")); ?>

                    </a>
                  </li>
                  <?php endif; ?>
                </ul>
              </li>
              <?php endif; ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <?php echo e(__("Lang")); ?>

                </a>
                <ul class="dropdown-menu">
                  <li>
                    <a class="dropdown-item" href="<?php echo e(route('app.change-lang', 'en')); ?>">
                    <?php echo e(__("English")); ?>

                    </a>
                </li>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('app.change-lang', 'ru')); ?>">
                    <?php echo e(__("Russian")); ?>

                    </a>
                </li>
                </ul>
              </li>
                    <?php if(auth()->user()): ?>
                        <li class="nav-item text-light mx-3">
                            <?php echo e(auth()->user()->name); ?>

                        </li>
                        <li class="nav-item text-light mx-3">

                            <form action="<?php echo e(route('auth.logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><?php echo e(__("app.menu.logout")); ?></button>
                            </form>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="<?php echo e(route('auth.register')); ?>"><?php echo e(__("Register")); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="<?php echo e(route('auth.login-page')); ?>"><?php echo e(__("LogIn")); ?></a>
                        </li>
                    <?php endif; ?>
                </ul>
          </div>
        </div>
      </nav>
</header><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/layouts/header.blade.php ENDPATH**/ ?>