

<?php $__env->startSection('title', $trademark->name . ' (ред.)'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center my-5">
    <h2><?php echo e($trademark->name . ' (ред.)'); ?></h2>
</div>

<div>
    <form action="<?php echo e(route('trademarks.update', $trademark->id)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field("PUT"); ?>
        <div class="form-group mb-3">
            <label for="name" class="form-label">Название бренда</label>
            <input type="text" id="name" name="name" value="<?php echo e($trademark->name); ?>" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Сохранить</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/trademarks/edit.blade.php ENDPATH**/ ?>