

<?php $__env->startSection('title', 'Новости'); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center my-5">
        <h2>Новости</h2>
    </div>

    <div>
        <h1 class="my-5"><?php echo e($article->title); ?></h1>
        <p><?php echo e($article->content); ?></p>
        <p>Категория: <?php echo e($article->category->name); ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/articles/article-show.blade.php ENDPATH**/ ?>