

<?php $__env->startSection('title', __("Trademarks")); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center my-5">
        <h2><?php echo e(__("Trademarks")); ?></h2>
        <a href="<?php echo e(route('trademarks.create')); ?>" class="btn btn-primary"><?php echo e(__("Add")); ?></a>
    </div>

    <div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th><?php echo e(__("Trademark")); ?></th>
                    <th><?php echo e(__("Actions")); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $trademarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trademark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($trademark->id); ?></td>
                        <td><?php echo e($trademark->name); ?></td>
                        <td class="d-flex">
                            <a href="<?php echo e(route('trademarks.edit', $trademark)); ?>" class="btn btn-sm btn-warning">
                            <?php echo e(__("Edit")); ?>

                            </a>
                            <form action="<?php echo e(route('trademarks.destroy', $trademark)); ?>" method="POST" class="mx-3">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                <?php echo e(__("Delete")); ?>

                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/trademarks/index.blade.php ENDPATH**/ ?>