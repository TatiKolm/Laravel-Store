<?php
return[
    'menu.home' => 'Home',
    'menu.dashboard'=> 'Dashboard',
    'menu.categories' => 'Categories',
    'menu.news' => 'News',
    'menu.logout' =>'Logout',
    'page.empty-news' => "There is no news",
];