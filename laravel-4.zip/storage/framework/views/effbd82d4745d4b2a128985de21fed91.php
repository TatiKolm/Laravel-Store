

<?php $__env->startSection("title", "Главная"); ?>

<?php $__env->startSection("content"); ?>
    <h1 class="my-5"><?php echo e(__("News")); ?></h1>
    
    <div class="row">
        <div class="col-sm-12 d-flex ">
        <?php if($articles->count()): ?>
    
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mx-3" style="width: 18rem;">
            <img src="<?php echo e($article->getImage()); ?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($article->title); ?></h5>
                <p class="card-text"><?php echo e($article->content); ?></p>
                <a href="#" class="btn btn-primary">Узнать больше</a>
            </div>
        </div>     
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p class="my-4">Нет ни одной новости.</p>
    <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/main.blade.php ENDPATH**/ ?>