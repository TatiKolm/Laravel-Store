


<h1><?php echo e($title); ?></h1>
<p><?php echo e($desc); ?></p>

<h3>Товары:</h3>
<ul>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($product); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/products.blade.php ENDPATH**/ ?>