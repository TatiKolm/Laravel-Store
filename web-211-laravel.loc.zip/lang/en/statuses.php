<?php
return [
    'in_process' => 'In Process',
    'finished' => 'Finished',
    'canceled' =>'Canceled',
    'paid' => 'Paid'
];