<?php
return [
    'in_process' => 'В обработке',
    'finished' => 'Завершен',
    'canceled' =>'Отменен',
    'paid' => 'Оплачен'
];