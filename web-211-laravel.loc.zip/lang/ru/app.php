<?php
return[
    'menu.home' => 'Главная',
    'menu.dashboard'=> 'Консоль',
    'menu.categories' => 'Категории',
    'menu.news' => 'Новости',
    'menu.logout' =>'Выйти',
    'page.empty-news' => "Нет ни одной новости",
];