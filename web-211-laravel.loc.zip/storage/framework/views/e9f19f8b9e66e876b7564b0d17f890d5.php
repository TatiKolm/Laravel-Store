

<?php $__env->startSection('title', 'Все заказы'); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center my-5">
        <h2><?php echo e(__("Все заказы")); ?></h2>
    </div>

    <div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ФИО</th>
                    <th>Товар</th>
                    <th>Сумма</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->getCustomerFullName()); ?></td>
                        <td>
                            <ul>
                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($item->product->title); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                        <td><?php echo e(priceFormat($order->total_sum)); ?></td>
                        <td>
                            <form action="<?php echo e(route('order.change-status', $order)); ?>" method="GET">
                                <select name="status" class="change-status form-control">
                                    <option value="in_process" <?php if($order->status == 'in_process'): ?> selected <?php endif; ?>><?php echo e(__('statuses.in_process')); ?></option>
                                    <option value="finished" <?php if($order->status == 'finished'): ?> selected <?php endif; ?>><?php echo e(__('statuses.finished')); ?></option>
                                    <option value="canceled" <?php if($order->status == 'canceled'): ?> selected <?php endif; ?>><?php echo e(__('statuses.canceled')); ?></option>
                                    <option value="paid" <?php if($order->status == 'paid'): ?> selected <?php endif; ?>><?php echo e(__('statuses.paid')); ?></option>
                                </select>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>