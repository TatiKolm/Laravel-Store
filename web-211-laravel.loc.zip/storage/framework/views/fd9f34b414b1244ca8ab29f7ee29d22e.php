

<?php $__env->startSection("title", "Корзина"); ?>

<?php $__env->startSection("content"); ?>
    <h1 class="my-5"><?php echo e(__("Корзина")); ?></h1>
    <?php if($cart): ?>
    <div class="row">
       <div class="col-lg-8 col-12">
        <table class="table table-striped">
            <div class="head">
                <tr>
                    <th>Изображение</th>
                    <th>Наименование</th>
                    <th>Цена</th>
                    <th>Количество</th>
                    <th>Итог</th>
                    <th>Удалить</th>
                </tr>
            </div>
            <tbody>
                <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="<?php echo e($item->product->getImage()); ?>" alt="" width="100px"></td>
                    <td><?php echo e($item->product->title); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td>
                        <form action="<?php echo e(route('cart.item.qty-update', $item)); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field("PUT"); ?>
                            <input type="number" class="form-control change-qty" name="quantity" value="<?php echo e($item->quantity); ?>" min="1">
                        </form>
                    </td>
                    <td><?php echo e($item->sub_total); ?></td>
                    <td>
                        <form action="<?php echo e(route('cart.item.destroy', $item)); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
                            <button class="btn btn-danger btn-sm">Удалить</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
        </table>
        
       </div>
       <div class="col-lg-4 col-12">
        <div>
            <h3 class="mb-2">Итого</h3>
            <p class="mb-2">Сумма заказа</p>
            <!-- <h4 class="mb-2"><?php echo e($cart->getTotalPriceHTML()); ?></h4> -->
            <h4 class="mb-2"><?php echo e(priceFormat($cart->getTotalPrice())); ?></h4>
            <a href="<?php echo e(route('app.checkout')); ?>" class="btn btn-primary">Оформить заказ</a>
        </div>
        </div>              
    </div>
    <?php else: ?>
    <div>
        <p>Ваша корзина пуста</p>
        <a href="/" class="btn btn-success">Вернуться на главную</a>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/cart.blade.php ENDPATH**/ ?>