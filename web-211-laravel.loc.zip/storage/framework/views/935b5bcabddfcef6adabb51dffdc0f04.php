

<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('content'); ?>

    <div>
        <h1 class="my-5"><?php echo e($product->title); ?></h1>
        <div class="row">
            <div class="col-3">
                <img src="<?php echo e($product->getImage()); ?>" alt="" style="height:200px">
            </div>
            <div class="col">
                <p><?php echo e($product->description); ?></p>
                <p>
                    <?php $__currentLoopData = $product->trademarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trademark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $trademark->name . '<br>'; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
            </div>
        </div>
        
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/products/show.blade.php ENDPATH**/ ?>