

<?php $__env->startSection("title", "Заказ"); ?>

<?php $__env->startSection("content"); ?>
    <h1 class="my-5"><?php echo e(__("Спасибо за заказ!")); ?></h1>

    <p class="mb-">
        Ваш заказ №<?php echo e($order->id); ?> успешно оформлен! 
        Статус заказа - <?php echo e(__('statuses.'.$order->status)); ?>

    </p>
    <div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Товар</th>
                    <th>Количество</th>
                    <th>Цена</th>
                    <th>Сумма</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product->title); ?> </td>
                        <td><?php echo e($item->quantity); ?> </td>
                        <td><?php echo e($item->price); ?> </td>
                        <td><?php echo e(priceFormat($item->subtotal)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <a href="/" class="btn btn-success">Вернуться на главную</a>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/order-thankyou.blade.php ENDPATH**/ ?>