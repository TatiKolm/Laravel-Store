<h3>Заказ № <?php echo e($order->id); ?> оформлен на сайте</h3>
<p>Заказчик <?php echo e($order->user_surname . " " . $order->user_name); ?></p>
<p>Телефон <?php echo e($order->phone); ?></p>
<p>Email <?php echo e($order->email); ?></p>
<h3>Состав заказа</h3>
<table>
    <tr>
        <th>Наименование</th>
        <th>Цена</th>
        <th>Количество</th>
        <th>Сумма</th>
    </tr>
    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->product->title); ?></td>
        <td><?php echo e(priceFormat($item->price)); ?></td>
        <td><?php echo e($item->quantity); ?></td>
        <td><?php echo e(priceFormat($item->subtotal)); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/mails/order-success-to-admin.blade.php ENDPATH**/ ?>