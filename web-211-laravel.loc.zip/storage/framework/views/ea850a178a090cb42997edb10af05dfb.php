<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ElectronicStore - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <style>
        .sticky-message{
            position: fixed;
            top: 100px;
            right: 30px;
        }
    </style>
</head>
<body>
    <?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <div class="container">
            <?php echo $__env->yieldContent("content"); ?>
        </div>
    </main>

    <div class="sticky-message"></div>

<script src="<?php echo e(asset('assets/js/jquery-3.6.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.js')); ?>"></script>
<?php echo $__env->yieldContent('page-scripts'); ?>
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/app.blade.php ENDPATH**/ ?>