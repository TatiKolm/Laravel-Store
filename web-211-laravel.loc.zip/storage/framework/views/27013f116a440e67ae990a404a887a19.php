

<?php $__env->startSection("title", "Главная"); ?>

<?php $__env->startSection("content"); ?>
    <h1 class="my-5"><?php echo e(__("Product")); ?></h1>
    
    <div class="row">
       <div class="col-lg-6 col-12">
        <div>
            <img src="<?php echo e($product->getImage()); ?>" alt="" style="height:200px">
        </div>
       </div>
       <div class="col-lg-6 col-12">
        <h1 class="mb-3"><?php echo e($product->title); ?></h1>
        <div class="mb-3"><?php echo e($product->description); ?></div>
        <div class="mb-3"><?php echo $product->getTrademarks(); ?></div>
        <div class="mb-3"><?php echo e($product->getPrice()); ?></div>
        <div class="mb-3">
            <a href="<?php echo e(route('cart.add-product', $product)); ?>" type="button" class="btn btn-success add-to-cart">В корзину</a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        </div>              
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/product-page.blade.php ENDPATH**/ ?>