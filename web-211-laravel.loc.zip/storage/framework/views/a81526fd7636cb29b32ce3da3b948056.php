

<?php $__env->startSection('title', $product->title . ' (ред.)'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center my-5">
    <h2><?php echo e($product->title . ' (ред.)'); ?></h2>
</div>

<div>
    <form action="<?php echo e(route('products.update',$product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <?php echo method_field("PUT"); ?>
        <div class="form-group mb-3">
            <label for="title" class="form-label">Название товара</label>
            <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title', $product->title)); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-denger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label for="description" class="form-label">Описание товара</label>
            <textarea type="text" id="description" name="description" class="form-control"><?php echo e(old('description', $product->description)); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-denger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <label for="image" class="form-label">Изображение</label>
            <input type="file" id="image" name="image" class="form-control">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-denger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
            <span>Торговая марка</span>
            <?php $__currentLoopData = $trademarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trademark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label for="<?php echo e('trademark_' . $trademark->id); ?>" class="form-label">
                        <input type="checkbox" id="<?php echo e('trademark_' . $trademark->id); ?>" name="trademarks[]" class="form-check-input"
                            value="<?php echo e($trademark->id); ?>" <?php if($product->trademarks->contains(old('trademark_' . $trademark->id, $trademark->id))): ?> checked <?php endif; ?>>
                        <?php echo e($trademark->name); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/products/edit.blade.php ENDPATH**/ ?>