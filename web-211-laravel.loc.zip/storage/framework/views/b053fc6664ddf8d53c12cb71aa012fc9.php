

<?php $__env->startSection("title", "Оформление заказа"); ?>

<?php $__env->startSection("content"); ?>
    <h1 class="my-5"><?php echo e(__("Оформление заказа")); ?></h1>
    <form action="<?php echo e(route('app.store-order')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4 col-12">
                <div class="form-group mb-3">
                    <label for="user_surname" >Фамилия</label>
                    <input type="text" id="user_surname" name="user_surname" class="form-control" value="<?php echo e(old('user_surname')); ?>">
                    <?php $__errorArgs = ['user_surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="form-group mb-3">
                    <label for="user_name" >Имя</label>
                    <input type="text" id="user_name" name="user_name" class="form-control" value="<?php echo e(old('user_name')); ?>">
                    <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="form-group mb-3">
                    <label for="user_patronymic" >Отчество</label>
                    <input type="text" id="user_patronymic" name="user_patronymic" class="form-control" value="<?php echo e(old('user_patronymic')); ?>">
                </div>
            </div>
            <div class="col-12">
                <div class="form-group mb-3">
                    <label for="phone">Телефон</label>
                    <input type="text" id="phone" name="user_phone" class="form-control" value="<?php echo e(old('user_phone')); ?>">
                </div>
            </div>
            <div class="col-12">
                <div class="form-group mb-3">
                    <label for="user_email">Email</label>
                    <input type="text" id="user_email" name="user_email" class="form-control" value="<?php echo e(old('user_email', auth()->user()->email)); ?>">
                </div>
            </div>
        </div>

        <button class="btn btn-primary">Оформить заказ</button>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-scripts'); ?>
<script src="<?php echo e(asset('assets/js/jquery.inputmask.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/checkout.blade.php ENDPATH**/ ?>