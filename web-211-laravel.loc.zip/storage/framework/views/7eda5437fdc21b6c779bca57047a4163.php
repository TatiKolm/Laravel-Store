<h3>Здравствуйте, <?php echo e($order->user_name); ?></h3>

<p>Вы оформили заказ № <?php echo e($order->id); ?></p>
<h4>Ваш заказ</h4>
<table>
    <tr>
        <th>Наименование</th>
        <th>Цена</th>
        <th>Количество</th>
        <th>Сумма</th>
    </tr>
    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->product->title); ?></td>
        <td><?php echo e(priceFormat($item->price)); ?></td>
        <td><?php echo e($item->quantity); ?></td>
        <td><?php echo e(priceFormat($item->subtotal)); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Projects\web-211-laravel.loc\resources\views/mails/order-success.blade.php ENDPATH**/ ?>