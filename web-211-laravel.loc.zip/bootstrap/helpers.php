<?php

function priceFormat($price)
{
    return number_format($price, 0, ',', ' ') . " руб.";
}